const express = require('express');
const cors = require('cors');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(express.json());

const usersServiceUrl = process.env.USERS_SERVICE_URL || 'http://localhost:3001';
const productsServiceUrl = process.env.PRODUCTS_SERVICE_URL || 'http://localhost:3002';

function nowMs() {
  return Date.now();
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function generateRequestId() {
  if (typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  return crypto.randomBytes(16).toString('hex');
}

function log(level, message, fields = {}) {
  // Simple structured logs so request flows are easy to follow.
  const entry = {
    ts: new Date().toISOString(),
    level,
    service: 'gateway',
    msg: message,
    ...fields
  };
  console.log(JSON.stringify(entry));
}

function ensureRequestId(req, res, next) {
  const inbound = req.header('x-request-id');
  const requestId = typeof inbound === 'string' && inbound.trim() ? inbound.trim() : generateRequestId();
  req.requestId = requestId;
  res.setHeader('X-Request-Id', requestId);
  next();
}

function requestLogger(req, res, next) {
  const start = nowMs();
  log('info', 'request.start', {
    requestId: req.requestId,
    method: req.method,
    path: req.path
  });

  res.on('finish', () => {
    log('info', 'request.end', {
      requestId: req.requestId,
      method: req.method,
      path: req.path,
      status: res.statusCode,
      durationMs: nowMs() - start
    });
  });

  next();
}

app.use(ensureRequestId);
app.use(requestLogger);

async function fetchJsonWithRetry(url, { requestId, timeoutMs, retries, retryDelayMs }) {
  let lastError = null;

  for (let attempt = 0; attempt <= retries; attempt += 1) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const response = await fetch(url, {
        signal: controller.signal,
        headers: { 'X-Request-Id': requestId }
      });

      if (!response.ok) {
        const error = new Error(`Downstream responded with HTTP ${response.status}`);
        error.status = response.status;
        throw error;
      }

      return await response.json();
    } catch (error) {
      lastError = error;
      const isTimeout = error && error.name === 'AbortError';
      const status = error && typeof error.status === 'number' ? error.status : null;
      const shouldRetry = attempt < retries && (isTimeout || status === null || status >= 500);

      log('warn', 'downstream.error', {
        requestId,
        url,
        attempt: attempt + 1,
        retries,
        timeoutMs,
        status,
        error: error && error.message ? error.message : String(error),
        willRetry: shouldRetry
      });

      if (!shouldRetry) break;
      await sleep(retryDelayMs * Math.pow(2, attempt));
    } finally {
      clearTimeout(timeout);
    }
  }

  throw lastError || new Error('Downstream request failed');
}

app.get('/health', (_req, res) => {
  res.json({ service: 'gateway', status: 'ok' });
});

app.get('/api/users', async (req, res) => {
  try {
    const data = await fetchJsonWithRetry(`${usersServiceUrl}/users`, {
      requestId: req.requestId,
      timeoutMs: 1500,
      retries: 1,
      retryDelayMs: 100
    });
    res.json(data);
  } catch (error) {
    res.status(502).json({
      requestId: req.requestId,
      error: 'Users service unavailable',
      detail: error.message
    });
  }
});

app.get('/api/products', async (req, res) => {
  try {
    const data = await fetchJsonWithRetry(`${productsServiceUrl}/products`, {
      requestId: req.requestId,
      timeoutMs: 1500,
      retries: 1,
      retryDelayMs: 100
    });
    res.json(data);
  } catch (error) {
    res.status(502).json({
      requestId: req.requestId,
      error: 'Products service unavailable',
      detail: error.message
    });
  }
});

app.get('/api/dashboard', async (req, res) => {
  const generatedAt = new Date().toISOString();

  const [usersResult, productsResult] = await Promise.allSettled([
    fetchJsonWithRetry(`${usersServiceUrl}/users`, {
      requestId: req.requestId,
      timeoutMs: 1500,
      retries: 1,
      retryDelayMs: 100
    }),
    fetchJsonWithRetry(`${productsServiceUrl}/products`, {
      requestId: req.requestId,
      timeoutMs: 1500,
      retries: 1,
      retryDelayMs: 100
    })
  ]);

  const responseBody = {
    requestId: req.requestId,
    generatedAt,
    users: null,
    products: null,
    errors: {}
  };

  if (usersResult.status === 'fulfilled') {
    responseBody.users = usersResult.value;
  } else {
    responseBody.errors.users = usersResult.reason && usersResult.reason.message
      ? usersResult.reason.message
      : String(usersResult.reason);
  }

  if (productsResult.status === 'fulfilled') {
    responseBody.products = productsResult.value;
  } else {
    responseBody.errors.products = productsResult.reason && productsResult.reason.message
      ? productsResult.reason.message
      : String(productsResult.reason);
  }

  if (Object.keys(responseBody.errors).length === 0) delete responseBody.errors;

  // 200 OK even if one downstream fails, so the UI can still render partial data.
  // For a stricter gateway, you could return 502 when either side fails.
  res.json(responseBody);
});

const port = 8080;
app.listen(port, () => {
  log('info', 'gateway.listening', { port });
});
