const gatewayBaseUrl = 'http://localhost:8080';

async function loadDashboard() {
  const rawOutput = document.getElementById('rawOutput');
  const usersList = document.getElementById('usersList');
  const productsList = document.getElementById('productsList');

  rawOutput.textContent = 'Loading...';
  usersList.innerHTML = '';
  productsList.innerHTML = '';

  try {
    const response = await fetch(`${gatewayBaseUrl}/api/dashboard`);
    const data = await response.json();

    data.users.forEach((user) => {
      const li = document.createElement('li');
      li.textContent = `${user.name} (${user.email})`;
      usersList.appendChild(li);
    });

    data.products.forEach((product) => {
      const li = document.createElement('li');
      li.textContent = `${product.name} - $${product.price}`;
      productsList.appendChild(li);
    });

    rawOutput.textContent = JSON.stringify(data, null, 2);
  } catch (error) {
    rawOutput.textContent = `Request failed: ${error.message}`;
  }
}

document.getElementById('loadDashboard').addEventListener('click', loadDashboard);
