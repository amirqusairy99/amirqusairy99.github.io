const express = require('express');
const crypto = require('crypto');
const app = express();

const users = [
  { id: 1, name: 'Alice Tan', email: 'alice@example.com' },
  { id: 2, name: 'Brian Lee', email: 'brian@example.com' },
  { id: 3, name: 'Carmen Ong', email: 'carmen@example.com' }
];

function nowMs() {
  return Date.now();
}

function generateRequestId() {
  if (typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  return crypto.randomBytes(16).toString('hex');
}

function log(level, message, fields = {}) {
  const entry = {
    ts: new Date().toISOString(),
    level,
    service: 'users-service',
    msg: message,
    ...fields
  };
  console.log(JSON.stringify(entry));
}

app.use((req, res, next) => {
  const inbound = req.header('x-request-id');
  const requestId = typeof inbound === 'string' && inbound.trim() ? inbound.trim() : generateRequestId();
  req.requestId = requestId;
  res.setHeader('X-Request-Id', requestId);

  const start = nowMs();
  log('info', 'request.start', { requestId, method: req.method, path: req.path });
  res.on('finish', () => {
    log('info', 'request.end', {
      requestId,
      method: req.method,
      path: req.path,
      status: res.statusCode,
      durationMs: nowMs() - start
    });
  });

  next();
});

app.get('/health', (_req, res) => {
  res.json({ service: 'users-service', status: 'ok' });
});

app.get('/users', (_req, res) => {
  res.json(users);
});

const port = process.env.PORT || 3001;
app.listen(port, () => {
  log('info', 'service.listening', { port });
});
