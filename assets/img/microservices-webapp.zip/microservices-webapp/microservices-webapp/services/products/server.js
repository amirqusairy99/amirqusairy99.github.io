const express = require('express');
const crypto = require('crypto');
const app = express();

const products = [
  { id: 101, name: 'Starter Plan', price: 9 },
  { id: 102, name: 'Growth Plan', price: 29 },
  { id: 103, name: 'Enterprise Plan', price: 99 }
];

function nowMs() {
  return Date.now();
}

function generateRequestId() {
  if (typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  return crypto.randomBytes(16).toString('hex');
}

function log(level, message, fields = {}) {
  const entry = {
    ts: new Date().toISOString(),
    level,
    service: 'products-service',
    msg: message,
    ...fields
  };
  console.log(JSON.stringify(entry));
}

app.use((req, res, next) => {
  const inbound = req.header('x-request-id');
  const requestId = typeof inbound === 'string' && inbound.trim() ? inbound.trim() : generateRequestId();
  req.requestId = requestId;
  res.setHeader('X-Request-Id', requestId);

  const start = nowMs();
  log('info', 'request.start', { requestId, method: req.method, path: req.path });
  res.on('finish', () => {
    log('info', 'request.end', {
      requestId,
      method: req.method,
      path: req.path,
      status: res.statusCode,
      durationMs: nowMs() - start
    });
  });

  next();
});

app.get('/health', (_req, res) => {
  res.json({ service: 'products-service', status: 'ok' });
});

app.get('/products', (_req, res) => {
  res.json(products);
});

const port = process.env.PORT || 3002;
app.listen(port, () => {
  log('info', 'service.listening', { port });
});
